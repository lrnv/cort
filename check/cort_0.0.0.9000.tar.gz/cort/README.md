
# cort

<!-- badges: start -->
[![Travis build status](https://travis-ci.org/lrnv/cort.svg?branch=master)](https://travis-ci.org/lrnv/cort)
[![Codecov test coverage](https://codecov.io/gh/lrnv/cort/branch/master/graph/badge.svg)](https://codecov.io/gh/lrnv/cort?branch=master)
[![AppVeyor build status](https://ci.appveyor.com/api/projects/status/github/lrnv/cort?branch=master&svg=true)](https://ci.appveyor.com/project/lrnv/cort)
<!-- badges: end -->

The goal of cort is to ...

## Installation

You can install the released version of cort from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("cort")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(cort)
## basic example code
```

