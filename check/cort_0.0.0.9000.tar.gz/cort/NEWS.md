# cort 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.
* Trying to make the package run on travis. 
* We will target CRAN with this package. 
